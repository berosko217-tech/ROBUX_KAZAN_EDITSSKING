TIKLA KAZAN - TABLET SURUMU

1. ZIP dosyasini cikartin.
2. index.html dosyasini Chrome ile acin.
3. Yonetici bolumu ustteki Yonetici dugmesindedir. Sifre: 4578.

Not: Oyun kaydi ve odul talepleri bu tarayicida saklanir; internete gonderilmez. Bu HTML icindeki sifre guvenli sunucu dogrulamasi degildir. Gercek Robux gonderimi yapilmaz.
